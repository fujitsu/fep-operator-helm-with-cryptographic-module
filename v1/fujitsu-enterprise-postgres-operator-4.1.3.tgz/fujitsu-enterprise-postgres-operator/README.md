# Fujitsu Enterprise Postgres with Cryptographic Module Operator for Kubernetes Helm Chart

Fujitsu Enterprise Postgres delivers an enterprise-grade PostgreSQL in Kubernetes. This solution provides the flexibility of a hybrid cloud solution with operational simplicity, while delivering an enhanced distribution of PostgreSQL to support enterprise-level workloads and provide improved deployment and management, availability, performance, data governance and security.

The download and Use of the Product is strictly subject to the terms of the End User License Agreement with Fujitsu Limited found at https://www.fast.fujitsu.com/fujitsu-enterprise-postgres-license-agreements. Where the Product that has been embedded as a whole or part into a third party program, only Authorised Customers may download and use the Product.


## Supported platforms

Depending on the version of the Fujitsu Enterprise Postgres with Cryptographic Module Operator, it supports the following platforms:

| Helm Chart version    | Kubernetes                    | Architecture          |
|-----------------------|-------------------------------|-----------------------|
| v2.1.0                | 1.24, 1.25, 1.26              | amd64                 |
| v2.1.1                | 1.25, 1.26                    | amd64                 |
| v2.1.2                | 1.25, 1.26                    | amd64                 |
| v3.1.0                | 1.25, 1.26, 1.27              | amd64                 |
| v3.1.1                | 1.25, 1.26, 1.27              | amd64                 |
| v3.1.2                | 1.25, 1.26, 1.27              | amd64                 |
| v3.1.3                | 1.25, 1.26, 1.27              | amd64                 |
| v3.1.4                | 1.25, 1.26, 1.27, 1.28        | amd64                 |
| v4.1.0                | 1.27, 1.28, 1.29              | amd64                 |
| v4.1.1                | 1.27, 1.28, 1.29              | amd64                 |
| v4.1.2                | 1.27, 1.28, 1.29              | amd64                 |
| v4.1.3                | 1.27, 1.28, 1.29, 1.30, 1.31  | amd64                 |

## Quick Start

The Fujitsu Enterprise Postgres with Cryptographic Module Operator can be installed in any namespace to manage the lifecycle of a Postgres cluster using Fujitsu Enterprise Postgres Server with Cryptographic Module within that namespace. It holds the operator deployment and all dependent
objects like permissions, custom resources and corresponding StatefulSets.

### Installation

To create the namespace and deploy the operator, run the following commands

```sh
$ kubectl create namespace fep
$ helm repo add fep-repo https://fujitsu.github.io/fep-operator-helm-with-cryptographic-module/v1 
$ helm repo update 
$ helm install fep-operator fep/fujitsu-enterprise-postgres-operator -n fep
```

These commands deploy Fujitsu Enterprise Postgres with Cryptographic Module Operator on the Kubernetes cluster.

For details on how to deploy a FEPcluster using the installed Operator, please check the documentation at https://www.postgresql.fastware.com/product-manuals#VersionForK8s

## Uninstalling the Chart

To uninstall/delete the `fep-operator-release` deployment:

```sh
$ helm uninstall fep-operator
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## License information

Please note that the Fujitsu Enterprise Postgres with Cryptographic Module Operator installed with this Helm Chart must be purchased and use a product license.
