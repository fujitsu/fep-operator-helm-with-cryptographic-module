{{- /*
  Install faled when
  - .Values.multiNamespace is true
  - and .Values.createClusterRole is false
*/ -}}

{{- define "chart.validate" -}}

{{- if and .Values.multiNamespace (not .Values.createClusterRole) }}
{{- fail "invalid values: multiNamespace=true is not allowed when createClusterRole=false" }}
{{- end }}

{{- end -}}